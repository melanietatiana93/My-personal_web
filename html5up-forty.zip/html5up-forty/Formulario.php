<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
	$name = $_POST["name"];
	$email = $_POST["email"];
	$message = $_POST["message"];
	$to = "tucorreo@gmail.com"; // Cambia esto por tu dirección de correo electrónico
	$subject = "Mensaje de contacto de $name";
	$body = "Has recibido un mensaje de contacto de $name ($email):\n\n$message";
	$headers = "From: $email";
	if (mail($to, $subject, $body, $headers)) {
		echo "Gracias por tu mensaje.";
	} else {
		echo "Hubo un error al enviar tu mensaje. Por favor, inténtalo de nuevo más tarde.";
	}
}
?>
